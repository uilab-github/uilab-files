import numpy as np
from scipy.stats import rankdata, hmean
from scipy.special import psi
from collections import defaultdict

eps = 1e-30

class ltai:
    def __init__(self, num_topic, num_doc, num_author, num_voca, doc_cnt, doc_ids, cite_docs, doc_author, D_test, uc = 1.):
        self.num_topic = num_topic
        self.num_doc = num_doc
        self.num_author = num_author
        self.num_voca = num_voca
        self.doc_author = doc_author
        self.cite_docs = cite_docs

        self.doc_cnt = doc_cnt
        self.doc_ids = doc_ids

        self.unseen_concentration = uc
        self.seen_concentration = uc * 10.
        self.eta_prior = uc * 1.

        self.alpha = 1.
        self.beta_prior = 0.1

        self.delay = 1.
        self.kappa = 0.9

        self.eta_sample_size = 500

        # reconstruct document by author matrix
        self.author_doc = dict()
        for di in range(self.num_doc):
            authors = self.doc_author[di]
            for author in authors:
                if author not in self.author_doc.keys():
                    self.author_doc[author] = list()
                self.author_doc[author].append(di)
        
        # maintain list of cited documents for each doc
        self.cited_docs = defaultdict(list)
        for cite, citeds in enumerate(self.cite_docs):
            for cited in citeds:
                self.cited_docs[cited].append(cite)
        self.cited_docs = {k: np.array(self.cited_docs[k], dtype=np.int32) for k in range(self.num_doc)}

        self.author_citing_doc = dict()
        for author in range(self.num_author):
            tmp = []
            if author in self.author_doc.keys():
                docs = self.author_doc[author]
                for doc in docs:
                    citing_docs = self.cited_docs[doc]
                    tmp += [(doc, citing_doc) for citing_doc in citing_docs]
                self.author_citing_doc[author] = np.array(tmp)
            else:
                self.author_citing_doc[author] = np.array([])

        self.pi = np.zeros([self.num_doc,self.num_author])

        # author influence
        self.eta = np.zeros([self.num_author, self.num_topic])

        # influence of each author for each document pair
        self.pi_ij = dict()
        for di in range(self.num_doc):
            authors = self.doc_author[di]    
            self.pi_ij[di] = np.ones((self.num_doc, len(authors)))/float(len(authors))
            self.pi[di,authors] += np.sum(self.pi_ij[di],0)

        self.pi /= np.sum(self.pi, 1)[:,np.newaxis]

        self.gamma = np.random.gamma(100.,1./100, (self.num_doc, self.num_topic))
        self.gamma_test = np.random.gamma(100.,1./100, (D_test, self.num_topic))

        self.z_bar = self.gamma / np.sum(self.gamma, 1)[:,np.newaxis]
        self.z_bar_test = self.gamma / np.sum(self.gamma, 1)[:,np.newaxis]

        self.beta = np.random.gamma(100.,1./100, (self.num_topic, self.num_voca))

        self.mrr_link = []
        self.mrr_author = []
        self.heldout_ll = []

    def update_gamma(self, batch_size_negative_links, batch_size_gamma):
        #update gamma
        docs = np.random.choice(range(self.num_doc), batch_size_gamma)
        e_log_theta = psi(self.gamma) - psi(np.sum(self.gamma, 1))[:,np.newaxis]
        e_log_beta = psi(self.beta) - psi(np.sum(self.beta, 1))[:,np.newaxis]

        sstats = np.zeros([self.num_topic, self.num_voca])

        for di in docs:
            negative_samples = np.random.choice(np.setdiff1d(np.arange(self.num_doc), self.cited_docs[di]), size = batch_size_negative_links)
            negative_samples_rev = np.random.choice(np.setdiff1d(np.arange(self.num_doc), self.cite_docs[di]), size = batch_size_negative_links)

            positive_samples = self.cited_docs[di]
            positive_samples_rev = self.cite_docs[di]

            words = self.doc_ids[di]
            cnt = self.doc_cnt[di]
            authors = self.doc_author[di]
            doc_len = float(np.sum(cnt))
            gammad = self.gamma[di]
            z_bar_d = self.z_bar[di]
            e_log_theta_d = e_log_theta[di]

            new_phi = e_log_beta[:,words]+ e_log_theta_d[:,np.newaxis]  # K x W

            doc_pi = self.pi_ij[di]

            z_prod = z_bar_d * self.z_bar # D x K
            err = 1. - np.dot(z_prod[positive_samples], self.eta[authors].T) # D x A
            gradient = np.dot(doc_pi[positive_samples,:] * err, self.eta[authors]) * self.seen_concentration / doc_len # D x K
            gradient = np.sum(gradient * self.z_bar[positive_samples], 0) # K
            new_phi += gradient[:,np.newaxis]

            err = 0. - np.dot(z_prod[negative_samples], self.eta[authors].T) # D x A
            gradient3 = np.dot(doc_pi[negative_samples,:] * err, self.eta[authors]) * self.unseen_concentration / doc_len # D x K
            gradient3 = np.sum(gradient3 * self.z_bar[negative_samples], 0) # K
            gradient3 *= float((self.num_doc-len(positive_samples))/batch_size_negative_links)
            new_phi += gradient3[:,np.newaxis]

            gradient2 = np.zeros_like(gradient)
            for di2 in positive_samples_rev:
                authors = self.doc_author[di2]
                err = 1. - np.dot(z_prod[di2], self.eta[authors].T) # A
                tmp = np.dot(self.pi_ij[di2][di,:] * err, self.eta[authors]) * self.seen_concentration / doc_len 
                gradient2 += tmp * self.z_bar[di2]
            new_phi += gradient2[:,np.newaxis]            

            gradient4 = np.zeros_like(gradient)
            for di2 in negative_samples_rev:
                authors = self.doc_author[di2]
                err = 0. - np.dot(z_prod[di2], self.eta[authors].T) # A
                tmp = np.dot(self.pi_ij[di2][di,:] * err, self.eta[authors]) * self.unseen_concentration / doc_len 
                gradient4 += tmp * self.z_bar[di2]
            gradient4 *= float((self.num_doc-len(positive_samples_rev))/batch_size_negative_links)
            new_phi += gradient4[:,np.newaxis]

            new_phi -= np.max(new_phi,0)
            new_phi = np.exp(new_phi)
            new_phi = new_phi/np.sum(new_phi,0)

            z_bar_d = np.sum(cnt * new_phi, 1)/np.sum(cnt * new_phi)
            gammad = np.sum(cnt * new_phi, 1) + self.alpha
            e_log_theta_d = psi(gammad) - psi(np.sum(gammad))

            self.gamma[di] = gammad
            self.z_bar[di] = z_bar_d
            sstats[:, words] += (cnt * new_phi)

        return sstats

    def update_beta(self, vi_iter, sstats, batch_size_gamma):
        beta_hat = self.beta_prior + self.num_doc * sstats / float(batch_size_gamma)
        rho = pow(vi_iter + self.delay, -1 * self.kappa)
        self.beta = (1 - rho) * self.beta + rho * beta_hat

    def compute_pi(self):
        """
        pi_ij : which author is more influential for explaining the link (0,1) between document i and j
        pi : average influence of each author for each document (only for linked docs)
        """
        self.pi_ij = dict()
        self.pi = np.zeros([self.num_doc,self.num_author])
        self.pi_ones = np.zeros_like(self.pi)

        # compute the influence of author for each document pair (di,di2)
        for di in range(self.num_doc):
            authors = self.doc_author[di]
            
            DTT = self.z_bar[di] * self.z_bar

            #ll = - self.C[:,di][:,np.newaxis] * ((self.DxD[:,di][:,np.newaxis] - np.dot(DTT, self.eta[authors,:].T))**2) # DxA
            C = np.zeros(self.num_doc) + self.unseen_concentration
            C[self.DxD[:,di].nonzero()[0]] = self.seen_concentration
            ll = - C[:,np.newaxis] * ((self.DxD[:,di].toarray() - np.dot(DTT, self.eta[authors,:].T))**2) # DxA

            ll -= np.max(ll, 1)[:,np.newaxis]
            ll = np.exp(ll)
            ll /= np.sum(ll,1)[:,np.newaxis]

            self.pi_ij[di] = ll
            self.pi[di,authors] += np.sum(ll,0)+eps
            self.pi_ones[di,authors] += np.sum(ll[self.DxD[:,di].nonzero()[0]],0)+eps

        self.pi /= np.sum(self.pi, 1)[:,np.newaxis]
        self.pi_ones /= np.sum(self.pi_ones, 1)[:,np.newaxis]

    def update_eta(self, batch_size_eta):
        authors = np.random.choice(self.num_author, size=batch_size_eta, replace=False)
        prior = self.eta_prior * np.identity(self.num_topic)
        for author in authors:
            if len(self.author_citing_doc[author]) != 0:
                author_docs = self.author_doc[author]
                author_citing_pairs = self.author_citing_doc[author]
                author_idx = {doc : self.doc_author[doc].index(author) for doc in author_docs}

                _psi_positive = self.z_bar[author_citing_pairs[:, 0]] * self.z_bar[author_citing_pairs[:, 1]]
                _C_positive = np.array([self.pi_ij[doc_pair[0]][doc_pair[1]][author_idx[doc_pair[0]]] for doc_pair in author_citing_pairs]) * self.seen_concentration

                tmp_cited = np.random.choice(author_docs, self.eta_sample_size)
                tmp_citing = np.random.choice(np.setdiff1d(np.arange(self.num_doc), author_citing_pairs[:, 1]), self.eta_sample_size)
                _psi_negative = self.z_bar[tmp_cited] * self.z_bar[tmp_citing]
                _C_negative = np.array([self.pi_ij[doc_pair[0]][doc_pair[1]][author_idx[doc_pair[0]]] for doc_pair in zip(tmp_cited, tmp_citing)]) * self.unseen_concentration

                D = self.num_doc * len(author_docs)
                neg_pos_ratio = (D - len(author_citing_pairs))

                psiC_positive = _psi_positive.T * _C_positive
                psiC_negative = _psi_negative.T * _C_negative
                first = np.linalg.inv(np.dot(psiC_positive, _psi_positive) + (np.dot(psiC_negative, _psi_negative)) * neg_pos_ratio / float(self.eta_sample_size) + prior)
                second = np.dot(psiC_positive, np.ones(psiC_positive.shape[1])) + np.dot(psiC_negative, np.zeros(psiC_negative.shape[1])) * neg_pos_ratio / float(self.eta_sample_size)
                self.eta[author, :] = np.dot(first, second)

if __name__ == '__main__':
    import sys
    import pickle

    dataset = sys.argv[1]
    doc_cnt, doc_cnt_test = pickle.load(open('./dataset/%s/doc_cnt_splitted_set.pkl' % (dataset), 'rb'), encoding='latin1')
    doc_ids, doc_ids_test = pickle.load(open('./dataset/%s/doc_ids_splitted_set.pkl' % (dataset), 'rb'), encoding='latin1')
    doc_author, doc_author_test = pickle.load(open('./dataset/%s/authorprediction.pkl' % (dataset), 'rb'), encoding='latin1')
    id_name = pickle.load(open('./dataset/%s/authorid_authorname.pkl' % (dataset), 'rb'), encoding='latin1')
    links, test_links = pickle.load(open('./dataset/%s/doc_links_splitted_set.pkl' % (dataset), 'rb'), encoding='latin1')
    voca = pickle.load(open('./dataset/%s/bow.pkl' % (dataset), 'rb'), encoding='latin1')

    doc_author_original = pickle.load(open('./dataset/%s/doc_authorid.pkl' % (dataset), 'rb'), encoding='latin1')
    cite_docs_original = pickle.load(open('./dataset/%s/doc_links_asym.pkl' % (dataset), 'rb'), encoding='latin1')
    cited_docs_original = defaultdict(list)
    for cite, citeds in enumerate(cite_docs_original):
        for cited in citeds:
            cited_docs_original[cited].append(cite)
    cited_docs_original = {k: np.array(cited_docs_original[k], dtype=np.int32) for k in range(len(doc_author_original))}

    num_topic = int(sys.argv[2])
    max_iter = 2000
    num_doc = len(doc_cnt)
    num_author = len(id_name)
    num_voca = len(voca)

    model = ltai(num_topic, num_doc, num_author, num_voca, doc_cnt, doc_ids, links, doc_author, len(doc_ids_test))

    for iter in range(max_iter):

        sstats = model.update_gamma(batch_size_negative_links = 500, batch_size_gamma = 500)
        model.update_beta(vi_iter = iter, sstats = sstats, batch_size_gamma = 500)
        model.update_eta(batch_size_eta = num_author)
