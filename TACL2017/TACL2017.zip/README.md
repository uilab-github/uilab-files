# Joint Modeling of Topics, Citations, and Topical Authority in Academic Corpora

This folder contains python code implementation of LTAI (Latent Topical Authority Indexing) and the datasets that are used for evaluation.

## ltai.py
    Run the following command:
        python ltai.py cora 100
    where you can replace ‘cora’ with any other dataset (e.g., pnas, kdd, citeseer) and ‘100’ with any other number of topics. kdd dataset refers to the arxiv-physics dataset in the paper.
